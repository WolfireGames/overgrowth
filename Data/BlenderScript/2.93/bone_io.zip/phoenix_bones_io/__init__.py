bl_info = {
    "name": "Import/Export: Phoenix bones .phxbn",
    "author": "David Rosen, Shams Kitz",
    "version": (0,2),
    "blender": (2,80,0),
    "location": "File > Import/Export > PHXBN",
    "description": "Import Phoenix Bones (.phxbn format)",
    "warning": "",
    "category": "Import-Export"}

import array,math,operator,pathlib

import bpy
from mathutils import Vector,Matrix

_hinge_joint = 0
_amotor_joint = 1
_fixed_joint = 2

bone_dict = {}

#Create a dictionary like: bone_dict["Bone_0"] = {"Point IDs",[point, point]}
def CreateBonePointDictionary(bones):
    point_head = {}
    point_tail = {}
    first_point = Point()
    first_point.head_of = GetClosestRealChildren(bones["root"])
    points = [first_point]
    to_process = GetClosestRealChildren(bones["root"])
    while len(to_process) > 0:
        bone = to_process.pop(0)
        point = Point()
        point.tail_of.append(bone)
        new_list = GetClosestRealChildren(bone)
        for line in new_list:
            point.head_of.append(line)
            to_process.append(line)
        points.append(point)
    for point in points:
        for bone in point.head_of:
            point_head[bone] = point
        for bone in point.tail_of:
            point_tail[bone] = point
    index = 0
    for point in points:
        if point.id != -1:
            continue
        point.id = index
        index += 1
    for bone in bones:
        if not bone in point_head or not bone in point_tail:
            continue
        point_ids = Get4ByteIntArray()
        point_ids.append(point_head[bone].id)
        point_ids.append(point_tail[bone].id)
        if not bone.name in bone_dict:
            bone_dict[bone.name] = {}
        bone_dict[bone.name]["Point IDs"] = point_ids

def GetParentIDs(data):
    parent_ids = Get4ByteIntArray()
    for bone in data.edit_bones:
        if bone.name.split("_")[0] != "Bone":
            continue
        bone_id = int(bone.name.split("_")[-1])
        while bone_id >= len(parent_ids):
            parent_ids.append(-1)
        if not bone.parent or bone.parent.name == "root" or bone.parent.layers[29] == False:
            continue
        parent_bone_id = int(bone.parent.name.split("_")[-1])
        parent_ids[bone_id] = parent_bone_id
    data["parent_ids"] = parent_ids

def GetParents(data):
    parents = Get4ByteIntArray()
    for bone in data.edit_bones:
        if not bone_dict.get(bone.name) or not bone_dict[bone.name].get("Point IDs"):
            continue
        point_ids = bone_dict[bone.name]["Point IDs"]
        while len(parents) <= point_ids[1]:
            parents.append(-1)
        parents[point_ids[1]] = point_ids[0]
    data["parents"] = parents

def GetBoneMatZ(edit_bone):
    z_vec = (edit_bone.tail - edit_bone.head).normalized()
    x_vec = Vector((0,0,1))
    y_vec = x_vec.cross(z_vec).normalized()
    x_vec = y_vec.cross(z_vec).normalized()
    return [x_vec[0], x_vec[2], -x_vec[1], 0,
            y_vec[0], y_vec[2], -y_vec[1], 0,
            z_vec[0], z_vec[2], -z_vec[1], 0,
            0,0,0,1]

def GetBoneMat(edit_bone):
    z_vec = (edit_bone.tail-edit_bone.head).normalized()
    print("z_vec:",z_vec)
    y_vec = Vector((0,1,0))
    if abs(z_vec.dot(y_vec)) > 0.95:
        return GetBoneMatZ(edit_bone)
    x_vec = z_vec.cross(y_vec).normalized()
    y_vec = z_vec.cross(x_vec).normalized()
    return [x_vec[0], x_vec[2], -x_vec[1], 0,
            y_vec[0], y_vec[2], -y_vec[1], 0,
            z_vec[0], z_vec[2], -z_vec[1], 0,
            0,0,0,1]

def GetJoints(arm_obj, name_shift):
    joints = []
    for bone in arm_obj.pose.bones:
        for constraint in bone.constraints:
            name_parts = constraint.name.split("_")
            if constraint.type == "LIMIT_ROTATION" and constraint.owner_space == "LOCAL" and name_parts[0] == "RGDL":
                freedom = 0
                if constraint.min_x != constraint.max_x:
                    freedom += 1
                if constraint.min_y != constraint.max_y:
                    freedom += 1
                if constraint.min_z != constraint.max_z:
                    freedom += 1
                joint = Joint()
                joint.bone_ids.append(int(bone.name.split("_")[1]))
                if bone.parent and len(bone.parent.name.split("_")) > 1:
                    joint.bone_ids.append(int(bone.parent.name.split("_")[1]))
                else:
                    joint.bone_ids.append(0)
                if name_parts[1] != "Limit Rotation":
                    if name_shift.get(name_parts[1]) and \
                    arm_obj.pose.bones.get(name_shift[name_parts[1]]):
                        joint.bone_ids[1] = int(name_shift[name_parts[1]].split("_")[1])
                    else:
                        print("Could not find: "+name_parts[1])
                if freedom == 0:
                    joint.type.append(_fixed_joint)
                    joints.append(joint)
                if freedom == 1:
                    joint.type.append(_hinge_joint)
                    mat = arm_obj.matrix_world * bone.matrix
                    axis = Vector((mat[0][0], mat[0][1], mat[0][2])).normalized()
                    joint.axis.append(axis[0])
                    joint.axis.append(axis[2])
                    joint.axis.append(-axis[1])
                    joint.stop_angles.append(constraint.min_x)
                    joint.stop_angles.append(constraint.max_x)
                    joints.append(joint)
                if freedom > 1:
                    joint.type.append(_amotor_joint)
                    joint.stop_angles.append(constraint.min_y)
                    joint.stop_angles.append(constraint.max_y)
                    joint.stop_angles.append(constraint.min_x)
                    joint.stop_angles.append(constraint.max_x)
                    joint.stop_angles.append(constraint.min_z)
                    joint.stop_angles.append(constraint.max_z)
                    joints.append(joint)
    return joints

def GetIKBones(arm_obj, name_shift):
    ik_bones = []
    for bone in arm_obj.pose.bones:
        if arm_obj.data.edit_bones[bone.name].layers[29] == False:
            continue
        for constraint in bone.constraints:
            if constraint.type == "IK" and not constraint.target:
                bone_id = int(bone.name.split("_")[-1])
                ik_length = constraint.chain_count
                ik_bone = IKBone()
                ik_bone.name = constraint.name
                ik_bone.bone = bone_id
                ik_bone.chain = ik_length
                ik_bones.append(ik_bone)
    return ik_bones

def PHXBNFromArmature(context):
    scene = bpy.context.scene
    old_armature_object = context.active_object
    if not old_armature_object or old_armature_object.type != "ARMATURE":
        print ("Must select armature before exporting PHXBN")
        return
    if len(old_armature_object.children) == 0 or old_armature_object.children[0].type != "MESH":
        print("Armature must be the parent of a mesh.")
        return
    #Make a copy of the object so we don't mess up the original
    bpy.ops.object.mode_set(mode="OBJECT")
    bpy.ops.object.duplicate()
    arm_obj = context.active_object
    print ("Reading PHXBN from armature: ", arm_obj.name)
    #Set to edit mode so we can add connecting bones
    bpy.ops.object.mode_set(mode="EDIT")
    AddConnectingBones(arm_obj)
    #Extract metadata from armature object
    arm_data = arm_obj.data
    data = PHXBNdata()
    if arm_data.get("version"):
        data.version.append(arm_data["version"])
    else:
        data.version.append(11)
    if arm_data.get("rigging_stage"):
        data.rigging_stage.append(arm_data["rigging_stage"])
    else:
        data.rigging_stage.append(1)
    #Rename all bones to "root" or "Bone_X" where X is bone number
    name_shift = EnforceBoneNaming(arm_data)
    #Make an easy way to look up the points attached to each bone
    CreateBonePointDictionary(arm_data.edit_bones)
    #Count the number of points and bones
    num_points = 0
    num_bones = 0
    for bone in arm_data.edit_bones:
        if bone.name == "root" or bone.layers[29] == False:
            continue
        points = Get4ByteIntArray()
        to_array(points, bone_dict[bone.name]["Point IDs"])
        num_points = max(num_points, points[0]+1)
        num_points = max(num_points, points[1]+1)
        num_bones = num_bones + 1
    #Create storage space for bone information
    for i in range(num_bones):
        points = Get4ByteIntArray()
        data.bones.append(points)
        data.bone_mass.append(0)
        data.bone_com.append(0)
        data.bone_com.append(0)
        data.bone_com.append(0)
        data.bone_parents.append(-1)
        data.bone_swap.append(0)
        for j in range(16):
            data.bone_mat.append(0)
    #Create space for point spatial information
    vertices = array.array("f")
    for i in range(num_points*3):
        vertices.append(0)
    #Fill in the bone information
    num = 0
    for bone in arm_data.edit_bones:
        if bone.name == "root" or bone.layers[29] == False:
                continue
        points = Get4ByteIntArray()
        to_array(points, bone_dict[bone.name]["Point IDs"])
        bone_id = int(bone.name.split("_")[-1])
        data.bones[bone_id].append(points[0])
        data.bones[bone_id].append(points[1])
        vertices[points[0]*3+0] = bone.head[0]
        vertices[points[0]*3+1] = bone.head[1]
        vertices[points[0]*3+2] = bone.head[2]
        vertices[points[1]*3+0] = bone.tail[0]
        vertices[points[1]*3+1] = bone.tail[1]
        vertices[points[1]*3+2] = bone.tail[2]
        mass = 0.1
        if bone.get("Mass"):
            mass = bone["Mass"]
        data.bone_mass[bone_id] = mass
        COM = [0.0,0.0,0.0]
        if bone.get("COM"):
            COM = bone["COM"]
        data.bone_com[bone_id*3+0] = COM[0]
        data.bone_com[bone_id*3+1] = COM[1]
        data.bone_com[bone_id*3+2] = COM[2]
        mat = GetBoneMat(bone)
        if bone.get("mat"):
            mat = bone["mat"]
        for j in range(16):
            data.bone_mat[bone_id*16+j] = mat[j]
        swap = False
        if bone.get("Swap"):
            swap = bone["Swap"]
        data.bone_swap[bone_id] = swap
        if(data.bone_swap[bone_id]):
            data.bones[bone_id][0], data.bones[bone_id][1] = \
                data.bones[bone_id][1], data.bones[bone_id][0]
        if not bone.parent or bone.parent.name == "root" or bone.parent.layers[29] == False:
            data.bone_parents[bone_id] = -1
        else:
            parent = int(bone.parent.name.split("_")[-1])
            data.bone_parents[bone_id] = parent
        num = num + 1
    #Store the position of each point
    for i in range(num_points):
        vertex = array.array("f")
        vertex.append(vertices[i*3+0])
        vertex.append(vertices[i*3+1])
        vertex.append(vertices[i*3+2])
        data.vertices.append(vertex)
    #Extract joint and IK bone info
    data.joints = GetJoints(arm_obj, name_shift)
    data.ik_bones = GetIKBones(arm_obj, name_shift)
    #Get the mesh object and subtract its midpoint from each skeleton point position
    mesh_obj = old_armature_object.children[0]
    print("Uncentering armature in mesh")
    UnCenterArmatureInMesh(data, mesh_obj)
    #Convert Blender coordinates back to Phoenix coordinates
    for vertex in data.vertices:
        vertex[1], vertex[2] = vertex[2], -vertex[1]
    #Calculate the parent hierarchies for each bone and point
    if not arm_data.get("parent_ids") or len(arm_data["parent_ids"]) != num_bones:
        GetParentIDs(arm_data)
    to_array(data.parent_ids, arm_data["parent_ids"])
    if not arm_data.get("parents") or len(arm_data["parents"]) != num_points:
       GetParents(arm_data)
    to_array(data.parents, arm_data["parents"])
    #Extract the bone ids and weights for each mesh vertex
    mesh = mesh_obj.data
    num_verts = len(mesh.vertices)
    bone_ids = []
    bone_weights = []
    count = 0;
    for vert in mesh.vertices:
        new_bone_weights = []
        #For each vertex group, check if that bone is a real deformation bone.
        #If so, record bone id and weight for this vertex
        for i in range(len(vert.groups)):
            temp_name = mesh_obj.vertex_groups[vert.groups[i].group].name
            if not temp_name in name_shift:
                continue
            group_name = name_shift[temp_name]
            new_bone_weights.append(BoneWeight(int(group_name.split("_")[-1]), \
                                               vert.groups[i].weight))
        #Sort bone weights, and keep the four greatest
        new_bone_weights.sort(key=operator.attrgetter("weight"), reverse=True)
        new_bone_weights = new_bone_weights[0:4]
        while len(new_bone_weights)<4:
            new_bone_weights.append(BoneWeight(0,0.0))
        #Normalize the bone weights
        total = 0.0
        for i in range(4):
            total = total + new_bone_weights[i].weight
        for i in range(4):
            if total != 0:
                new_bone_weights[i].weight = new_bone_weights[i].weight / total
            else:
                print("Error: vertex ",count," has no weights!")
        #Record weights and id in list
        for bone_weight in new_bone_weights:
            bone_ids.append(bone_weight.id)
            bone_weights.append(bone_weight.weight)
        count = count + 1
    for face in mesh.polygons:
        print(face)
        for j in range(3):
            for i in range(4):
                index = face.vertices[j]*4+i
                data.bone_ids.append(bone_ids[index])
                data.bone_weights.append(bone_weights[index])
    print("Num polygons: ", len(mesh.polygons))
    print("Num bone weights: ", len(data.bone_weights))
    bpy.ops.object.mode_set(mode="OBJECT")
    bpy.ops.object.delete()
    context.view_layer.objects.active = old_armature_object
    # old_armature_object.select_set(True)
    return data

def WriteInt(file, val):
    int_loader = Get4ByteIntArray()
    int_loader.append(val)
    int_loader.tofile(file)

def WritePHXBN(file_path, data):
    file = open(file_path, "wb")
    print ("Saving phxbn file: ", file_path)
    data.version.tofile(file)
    print ("Version: ", data.version[0])
    data.rigging_stage.tofile(file)
    print ("Rigging stage: ", data.rigging_stage[0])
    num_points = Get4ByteIntArray()
    num_points.append(len(data.vertices))
    num_points.tofile(file)
    print ("Num points: ", num_points[0])
    for vertex in data.vertices:
        vertex.tofile(file)
    data.parents.tofile(file)
    num_bones = Get4ByteIntArray()
    num_bones.append(len(data.bones))
    num_bones.tofile(file)
    print ("Num bones: ", num_bones[0])
    for bone in data.bones:
        bone.tofile(file)
    data.bone_parents.tofile(file)
    data.bone_mass.tofile(file)
    data.bone_com.tofile(file)
    data.bone_mat.tofile(file)
    num_vertices = Get4ByteIntArray()
    num_vertices.append(len(data.bone_weights)//4)
    num_vertices.tofile(file)
    data.bone_weights.tofile(file)
    data.bone_ids.tofile(file)
    data.parent_ids.tofile(file)
    num_joints = Get4ByteIntArray()
    num_joints.append(len(data.joints))
    num_joints.tofile(file)
    print("Saving ", num_joints[0], " joints")
    for joint in data.joints:
        joint.type.tofile(file)
        if joint.type[0] == _amotor_joint:
            joint.stop_angles.tofile(file)
        elif joint.type[0] == _hinge_joint:
            joint.stop_angles.tofile(file)
        joint.bone_ids.tofile(file)
        if joint.type[0] == _hinge_joint:
            joint.axis.tofile(file)
    num_ik_bones = len(data.ik_bones)
    WriteInt(file, num_ik_bones)
    for ik_bone in data.ik_bones:
        WriteInt(file, ik_bone.bone)
        WriteInt(file, ik_bone.chain)
        string_array = array.array("B")
        string_array.frombytes(ik_bone.name.encode("utf-8"))
        WriteInt(file, len(string_array))
        string_array.tofile(file)
    file.close()

def Load(operator,filepath):
    mesh_obj = GetMeshObj()
    if not mesh_obj:
        operator.report({"WARNING"},"No mesh is selected!")
        print("No mesh is selected")
        return False
    data = ReadPHXBN(filepath, mesh_obj)
    if not data:
        return False
    AddArmature(data, mesh_obj)
    return True


def Save(context,filepath):
    data = PHXBNFromArmature(context)
    if not data:
        return
    WritePHXBN(filepath, data)

def menu_import(self,context):
    op = self.layout.operator(
        PHXBN_OT_import.bl_idname,
        text="Phoenix Bones (.phxbn)")
    # op.filepath = "*.phxbn"

def menu_export(self,context):
    row = self.layout.row()
    op = row.operator(
        PHXBN_OT_export.bl_idname,
        text="Phoenix Bones (.phxbn)")
    if not bpy.data.filepath:
        row.enabled = False
    else:
        op.filepath = str(pathlib.Path(bpy.data.filepath).with_suffix(".phxbn"))

def Get4ByteIntArray():
    var = array.array("l")
    if var.itemsize != 4:
        var = array.array("i")
    return var

def WriteToTextFile(file_path, data):
    file = open(file_path, "w")
    file.write("Version: "+str(data.version[0])+"\n")
    file.write("Rigging stage: "+str(data.rigging_stage[0])+"\n")
    file.write("Num points: "+str(len(data.vertices))+"\n")
    file.write("\nVertices:\n")
    for vertex in data.vertices:
        file.write(str(vertex)+"\n")
    file.write("\nParents:\n")
    for parent in data.parents:
        file.write(str(parent)+"\n")
    file.write("\nNum bones: "+str(len(data.bones))+"\n")
    file.write("\nBones:\n")
    for bone in data.bones:
        file.write(str(bone)+"\n")
    file.write("\nBone parents:\n")
    for bone_parent in data.bone_parents:
        file.write(str(bone_parent)+"\n")
    file.write("\nBone mass:\n")
    for bone_mass in data.bone_mass:
        file.write(str(bone_mass)+"\n")
    file.write("\nBone COM:\n")
    for bone_com in data.bone_com:
        file.write(str(bone_com)+"\n")
    file.write("Parent IDs:\n")
    for parent_id in data.parent_ids:
        file.write(str(parent_id)+"\n")
    file.write("\nNum joints: "+str(len(data.joints))+"\n")
    i = 0
    for joint in data.joints:
        file.write("\nJoint "+str(i)+":\n")
        file.write("Joint type: "+str(joint.type)+"\n")
        file.write("Stop angles: "+str(joint.stop_angles)+"\n")
        file.write("Bone ids: "+str(joint.bone_ids)+"\n")
        file.write("Axis: "+str(joint.axis)+"\n")
        i = i + 1
    file.close()

def ReadPHXBN(file_path, mesh_obj):
    # File loading stuff
    # Open the file for importing
    file = open(file_path, "rb")
    data = PHXBNdata();
    print ("\nLoading phxbn file: ", file_path)
    data.version.fromfile(file, 1)
    print ("Version: ", data.version[0], "\n")
    if data.version[0] < 8:
        print("PHXBN must be at least version 8.")
        return
    data.rigging_stage.fromfile(file, 1)
    print ("Rigging stage: ", data.rigging_stage[0], "\n")
    if data.rigging_stage[0] != 1:
        print("Rigging stage should be 1")
        return
    num_points = Get4ByteIntArray()
    num_points.fromfile(file, 1)
    print ("Num points: ", num_points[0], "\n")
    for i in range(0,num_points[0]):
        vertex = array.array("f")
        vertex.fromfile(file, 3)
        #Convert Phoenix coordinates to Blender coordinates
        vertex[1], vertex[2] = -vertex[2], vertex[1]
        data.vertices.append(vertex)
    for i in range(0,num_points[0]):
        parent = Get4ByteIntArray()
        parent.fromfile(file, 1)
        data.parents.append(parent[0])
    num_bones = Get4ByteIntArray()
    num_bones.fromfile(file, 1)
    print ("Num bones: ", num_bones[0], "\n")
    for i in range(0,num_bones[0]):
        bone = Get4ByteIntArray()
        bone.fromfile(file, 2)
        if data.parents[bone[0]]==bone[1]:
            temp = bone[0]
            bone[0] = bone[1]
            bone[1] = temp
            data.bone_swap.append(1)
        else:
            data.bone_swap.append(0)
        data.bones.append(bone)
    for i in range(0,num_bones[0]):
        bone_parent = Get4ByteIntArray()
        bone_parent.fromfile(file, 1)
        data.bone_parents.append(bone_parent[0])
    data.bone_mass.fromfile(file, num_bones[0])
    data.bone_com.fromfile(file, num_bones[0]*3)
    data.bone_mat.fromfile(file, num_bones[0]*16)
    mesh = mesh_obj.data
    print("mesh:",mesh)
    num_faces = len(mesh.polygons)
    num_verts = num_faces * 3
    file_bone_weights = array.array("f")
    file_bone_ids = array.array("f")
    file_bone_weights.fromfile(file, num_verts*4)
    file_bone_ids.fromfile(file, num_verts*4)
    num_verts = len(mesh.vertices)
    data.bone_weights = [0 for i in range(num_verts*4)]
    data.bone_ids = [0 for i in range(num_verts*4)]
    for face_id in range(num_faces):
        for face_vert_num in range(3):
            for i in range(4):
                data.bone_weights[mesh.polygons[face_id].vertices[face_vert_num]*4+i] =file_bone_weights[face_id*12 + face_vert_num * 4 + i]
                data.bone_ids[mesh.polygons[face_id].vertices[face_vert_num]*4+i] =file_bone_ids[face_id*12 + face_vert_num * 4 + i]
    data.parent_ids.fromfile(file, num_bones[0])
    num_joints = Get4ByteIntArray()
    num_joints.fromfile(file, 1)
    for i in range(num_joints[0]):
        joint = Joint()
        joint.type.fromfile(file, 1)
        if joint.type[0] == _amotor_joint:
            joint.stop_angles.fromfile(file, 6)
        elif joint.type[0] == _hinge_joint:
            joint.stop_angles.fromfile(file, 2)
        joint.bone_ids.fromfile(file, 2)
        if joint.type[0] == _hinge_joint:
            joint.axis.fromfile(file, 3)
        data.joints.append(joint)
    file.close()
    return data

def GetMeshObj():
     for obj in bpy.context.selected_objects:
        if obj.type == "MESH":
           return obj

def GetMeshMidpoint(data, mesh_obj):
    mesh = mesh_obj.data
    min_point = array.array("f")
    max_point = array.array("f")
    for i in range(3):
        min_point.append(mesh.vertices[0].co[i])
        max_point.append(mesh.vertices[0].co[i])
    for vert in mesh.vertices:
        for i in range(3):
            min_point[i] = min(min_point[i], vert.co[i])
            max_point[i] = max(max_point[i], vert.co[i])
    mid_point = array.array("f")
    for i in range(3):
        mid_point.append((min_point[i] + max_point[i]) * 0.5)
    return mid_point

def GetD6Mat(edit_bone):
    vec = (edit_bone.tail - edit_bone.head).normalized()
    vec = Vector((vec[0], vec[2], -vec[1]))
    right = Vector((0.0001,1.0001,0.000003))
    up = vec.cross(right).normalized()
    right = up.cross(vec).normalized()
    return [right[0], right[1], right[2], 0,
            up[0], up[1], up[2], 0,
            vec[0],vec[1], vec[2], 0,
            0,0,0,1]

def AddFixedJoint(arm_obj,joint):
    joint_bones = []
    joint_bones.append(arm_obj.pose.bones["Bone_"+str(joint.bone_ids[0])])
    joint_bones.append(arm_obj.pose.bones["Bone_"+str(joint.bone_ids[1])])
    if joint_bones[0].parent == joint_bones[1]:
        child = joint_bones[0]
        parented = True
    elif joint_bones[1].parent == joint_bones[0]:
        child = joint_bones[1]
        parented = True
    else:
        child = joint_bones[1]
        parented = False
    constraint = child.constraints.new("LIMIT_ROTATION")
    constraint.use_limit_x = True
    constraint.use_limit_y = True
    constraint.use_limit_z = True
    constraint.influence = 0.0
    constraint.owner_space = "LOCAL"
    if parented == False:
        constraint.name = joint_bones[0].name

def AddAmotorJoint(arm_obj,joint):
    joint_bones = []
    joint_bones.append(arm_obj.pose.bones["Bone_"+str(joint.bone_ids[0])])
    joint_bones.append(arm_obj.pose.bones["Bone_"+str(joint.bone_ids[1])])
    if joint_bones[0].parent == joint_bones[1]:
        child = joint_bones[0]
        parented = True
    elif joint_bones[1].parent == joint_bones[0]:
        child = joint_bones[1]
        parented = True
    else:
        child = joint_bones[1]
        parented = False
    constraint = child.constraints.new("LIMIT_ROTATION")
    constraint.min_x = joint.stop_angles[2]
    constraint.max_x = joint.stop_angles[3]
    constraint.min_y = joint.stop_angles[0]
    constraint.max_y = joint.stop_angles[1]
    constraint.min_z = joint.stop_angles[4]
    constraint.max_z = joint.stop_angles[5]
    constraint.use_limit_x = True
    constraint.use_limit_y = True
    constraint.use_limit_z = True
    constraint.influence = 0.0
    constraint.owner_space = "LOCAL"
    if parented == False:
        constraint.name = joint_bones[0].name
    matrix = GetD6Mat(arm_obj.data.edit_bones[child.name])
    joint_axis = Vector((matrix[0], -matrix[2], matrix[1]))
    mat = arm_obj.matrix_world * child.matrix
    x_axis = Vector((mat[0][0], mat[0][1], mat[0][2])).normalized()
    y_axis = Vector((mat[2][0], mat[2][1], mat[2][2])).normalized()
    joint_conv = Vector((-x_axis.dot(joint_axis), -y_axis.dot(joint_axis), 0)).normalized()
    roll = math.atan2(joint_conv[0], joint_conv[1])
    arm_obj.data.edit_bones[child.name].roll += roll
    child.rotation_mode = "YXZ"

def AddHingeJoint(arm_obj,joint):
    joint_bones = []
    joint_bones.append(arm_obj.pose.bones["Bone_"+str(joint.bone_ids[0])])
    joint_bones.append(arm_obj.pose.bones["Bone_"+str(joint.bone_ids[1])])
    joint_axis = Vector((joint.axis[0], -joint.axis[2], joint.axis[1]))
    if joint_bones[0].parent == joint_bones[1]:
        child = joint_bones[0]
        joint_axis *= -1
        parented = True
    elif joint_bones[1].parent == joint_bones[0]:
        child = joint_bones[1]
        parented = True
    else:
        child = joint_bones[1]
        parented = False
    constraint = child.constraints.new("LIMIT_ROTATION")
    constraint.min_x = joint.stop_angles[0]
    constraint.max_x = joint.stop_angles[1]
    constraint.use_limit_x = True
    constraint.use_limit_y = True
    constraint.use_limit_z = True
    constraint.influence = 0.0
    constraint.owner_space = "LOCAL"
    if parented == False:
        constraint.name = joint_bones[0].name
    mat = arm_obj.matrix_world * child.matrix
    x_axis = Vector((mat[0][0], mat[0][1], mat[0][2])).normalized()
    y_axis = Vector((mat[2][0], mat[2][1], mat[2][2])).normalized()
    joint_conv = Vector((x_axis.dot(joint_axis), y_axis.dot(joint_axis), 0)).normalized()
    roll = math.atan2(joint_conv[0], joint_conv[1]) + math.pi / 2
    arm_obj.data.edit_bones[child.name].roll += roll
    child.rotation_mode = "XYZ"

def AddArmature(data, mesh_obj):
    scn = bpy.context.scene
    for ob in scn.objects:
        ob.select_set(False)
    mid_point = GetMeshMidpoint(data, mesh_obj)
    arm_data = bpy.data.armatures.new("MyPHXBN")
    arm_obj = bpy.data.objects.new("MyPHXBN",arm_data)
    if hasattr(arm_obj,"pose") and arm_obj.pose:
        arm_obj.pose.use_auto_ik = True
    scn.collection.objects.link(arm_obj)
    arm_obj.select_set(True)
    arm_obj.location = mid_point
    bpy.context.view_layer.objects.active = arm_obj
    arm_data["version"] = data.version[0]
    arm_data["rigging_stage"] = data.rigging_stage[0]
    bpy.ops.object.mode_set(mode="EDIT")
    bpy.ops.armature.delete()
    bpy.ops.armature.select_all()
    bpy.ops.armature.delete()
    mesh = mesh_obj.data
    min_point = array.array("f")
    max_point = array.array("f")
    for i in range(3):
        min_point.append(mesh.vertices[0].co[i])
        max_point.append(mesh.vertices[0].co[i])
    for vert in mesh.vertices:
        for i in range(3):
            min_point[i] = min(min_point[i], vert.co[i])
            max_point[i] = max(max_point[i], vert.co[i])
    num = 0
    for data_bone in data.bones:
        bpy.ops.armature.bone_primitive_add(name="Bone_"+str(num))
        bone = arm_data.edit_bones[-1]
        bone.use_connect = True
        bone["Point IDs"] = data_bone
        bone["Swap"] = data.bone_swap[num]
        bone.head = Vector((data.vertices[data_bone[0]][0],
                     data.vertices[data_bone[0]][1],
                     data.vertices[data_bone[0]][2]))
        bone.tail = Vector((data.vertices[data_bone[1]][0],
                     data.vertices[data_bone[1]][1],
                     data.vertices[data_bone[1]][2]))
        bone["Mass"] = data.bone_mass[num]
        bone["COM"] = [data.bone_com[num*3+0],
                       data.bone_com[num*3+1],
                       data.bone_com[num*3+2]]
        bone["mat"] = data.bone_mat[num*16:num*16+16]
        num = num + 1
    bpy.ops.armature.bone_primitive_add(name="root")
    bone = arm_data.edit_bones[-1]
    bone.head = Vector(((min_point[0]+max_point[0])*0.5,
                        (min_point[1]+max_point[1])*0.5+0.5,
                        -mid_point[2]))
    bone.tail = Vector(((min_point[0]+max_point[0])*0.5,
                        (min_point[1]+max_point[1])*0.5+0.25,
                        -mid_point[2]))
    num = 0
    for bone_parent in data.bone_parents:
        name = "Bone_"+str(num);
        parent_name = "Bone_"+str(bone_parent)
        if bone_parent != -1:
            arm_data.edit_bones[name].parent = arm_data.edit_bones[bone_parent]
        else:
            arm_data.edit_bones[name].use_connect = False
            arm_data.edit_bones[name].parent = arm_data.edit_bones["root"]
        num = num + 1
    bpy.context.view_layer.update()
    bpy.ops.object.mode_set(mode="OBJECT")
    bpy.context.view_layer.objects.active = mesh_obj
    if len(mesh_obj.vertex_groups):
        bpy.ops.object.vertex_group_remove(all=True)
    vertgroup_created=[]
    for bone in data.bones:
        vertgroup_created.append(0)
    mesh = mesh_obj.data
    index = 0
    vert_index = 0
    for vert in mesh.vertices:
        for bone_num in range(0,4):
            bone_id = int(data.bone_ids[index])
            bone_weight = data.bone_weights[index]
            name = "Bone_"+str(bone_id);
            if vertgroup_created[bone_id]==0:
                vertgroup_created[bone_id]=1
                mesh_obj.vertex_groups.new(name=name)
            #assign the weight for this vertex
            print(dir(mesh_obj.vertex_groups))
            mesh_obj.vertex_groups[name].add([vert_index],
                                     bone_weight,
                                     "REPLACE")
            index = index + 1
        vert_index = vert_index + 1
    mesh.update()
    mesh_obj.select_set(True)
    bpy.context.view_layer.objects.active = arm_obj
    bpy.ops.object.parent_set(type="ARMATURE")
    # | property was
    # v removed
    # arm_obj.show_x_ray = True
    def ncr(n, r):
        return math.factorial(n) / \
              (math.factorial(r) * math.factorial(n - r))
    # v unused?
    def CountJoints(bone):
        num_children = len(bone.children)
        if num_children == 0:
            return 0
        if bone.name != "root":
            num_children += 1
        count = ncr(num_children, 2)
        for child in bone.children:
            count += CountJoints(child)
        return int(count)
    arm_data["parents"] = data.parents
    arm_data["parent_ids"] = data.parent_ids
    bpy.ops.object.mode_set(mode="EDIT")
    for joint in data.joints:
        if joint.type[0] == _hinge_joint:
            AddHingeJoint(arm_obj, joint)
        if joint.type[0] == _amotor_joint:
            AddAmotorJoint(arm_obj, joint)
        if joint.type[0] == _fixed_joint:
            AddFixedJoint(arm_obj, joint)

def UnCenterArmatureInMesh(data, mesh_obj):
    mesh = mesh_obj.data
    min_point = array.array("f")
    max_point = array.array("f")
    for i in range(3):
        min_point.append(mesh.vertices[0].co[i])
        max_point.append(mesh.vertices[0].co[i])
    for vert in mesh.vertices:
        for i in range(3):
            min_point[i] = min(min_point[i], vert.co[i])
            max_point[i] = max(max_point[i], vert.co[i])
    mid_point = Vector();
    for i in range(3):
        mid_point[i] = ((min_point[i] + max_point[i]) * 0.5)
    mid_point = mesh_obj.matrix_world @ mid_point;
    for vert in data.vertices:
        for i in range(3):
            vert[i] = vert[i] - mid_point[i]

def to_array(array, idarray):
    for item in idarray:
        array.append(item)

def AddConnectingBones(arm_obj):
    new_bones = []
    arm_data = arm_obj.data
    for bone in arm_data.edit_bones:
        if bone.name == "root" or bone.layers[29] == False or not bone.parent or bone.parent.name == "root" or bone.parent.layers[29] == False:
            continue
        if bone.head != bone.parent.tail:
            bpy.ops.armature.bone_primitive_add(name="connector")
            new_bone = arm_data.edit_bones[-1]
            new_bone.head = bone.parent.tail
            new_bone.tail = bone.head
            new_bone.parent = bone.parent
            new_bone["Mass"] = 0.01
            for i in range(32):
                new_bone.layers[i] = False
            new_bone.layers[29] = True
            bone.parent = new_bone
            new_bones.append(new_bone.name)
    bpy.context.view_layer.update()
    bpy.ops.object.mode_set(mode="OBJECT")
    bpy.ops.object.mode_set(mode="EDIT")

def EnforceBoneNaming(arm_data):
    name_shift = {}
    bone_labels = {}
    for bone in arm_data.edit_bones:
        if bone.name == "root" or bone.layers[29] == False:
            continue
        if bone.name.split("_")[0] == "Bone":
            bone_id = int(bone.name.split("_")[-1])
            bone_labels[bone_id] = True
            name_shift[bone.name] = bone.name
    index = 0
    for bone in arm_data.edit_bones:
        if bone.name == "root" or bone.layers[29] == False:
            continue
        if bone.name.split("_")[0] != "Bone":
            while index in bone_labels:
                index = index + 1
            name_shift[bone.name] = "Bone_"+str(index)
            bone.name = name_shift[bone.name]
            index = index+1
    return name_shift

def GetClosestRealChildren(bone):
    list = []
    for child in bone.children:
        if not child.layers[29]:
            new_list = GetClosestRealChildren(child)
            for line in new_list:
                list.append(line)
            continue
        list.append(child)
    return list


class IKBone:
    def __init__(self):
        self.name = ""
        self.bone = 0
        self.chain = 0


class Joint:
    def __init__(self):
        self.type = Get4ByteIntArray()
        self.stop_angles = array.array("f")
        self.bone_ids = Get4ByteIntArray()
        self.axis = array.array("f")


class PHXBNdata:
    def __init__(self):
        self.vertices = []
        self.bones = []
        self.parents = Get4ByteIntArray()
        self.bone_parents = Get4ByteIntArray()
        self.bone_weights = array.array("f")
        self.bone_ids = array.array("f")
        self.bone_swap = Get4ByteIntArray()
        self.bone_mass = array.array("f")
        self.bone_com = array.array("f")
        self.rigging_stage = Get4ByteIntArray()
        self.version = Get4ByteIntArray()
        self.parent_ids = Get4ByteIntArray()
        self.joints = []
        self.bone_mat = array.array("f")
        self.ik_bones = []


class BoneWeight:
    def __init__(self, id, weight):
        self.id = id
        self.weight = weight


class Point():
    def __init__(self):
        self.head_of = []
        self.tail_of = []
        self.id = -1


class PHXBN_OT_import(bpy.types.Operator):
    """Load Phoenix Bones armature"""
    bl_idname = "phxbn.import_phxbn"
    bl_label = "Import PHXBN"
    filepath: bpy.props.StringProperty(
        name="File Path",
        subtype="FILE_PATH",
        description="Filepath used for importing the PHXBN file",
        maxlen=1024,
        default="")
    filter_glob: bpy.props.StringProperty(
        name="PHXBN file type",
        options={"HIDDEN"},
        default="*.phxbn")
    def invoke(self,context,event):
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}
    def execute(self, context):
        print("self.filepath:",self.filepath)
        print("Filepath:",self.properties.filepath)
        if not self.filepath:
            return {"CANCELLED"}
        load_success = Load(self,self.properties.filepath)
        if not load_success:
            return {"CANCELLED"}
        filename = self.properties.filepath.split("\\")[-1]
        #convert the filename to an object name
        objName = bpy.path.display_name(filename)
        print("Filename:",filename)
        #mesh = readMesh(self.properties.filepath, objName)
        #addMeshObj(mesh, objName)
        return {"FINISHED"}


class PHXBN_OT_export(bpy.types.Operator):
    """Save Phoenix Bones armature"""
    bl_idname = "phxbn.export_phxbn"
    bl_label = "Export PHXBN"
    filepath: bpy.props.StringProperty(
        name="File Path",
        subtype="FILE_PATH",
        description="Filepath used for exporting the PHXBN file",
        maxlen= 1024,
        default= "")
    check_existing: bpy.props.BoolProperty(
        name="Check Existing",
        description="Check and warn on overwriting existing files",
        default=True,
        options={"HIDDEN"})
    def execute(self, context):
        Save(context,self.properties.filepath)
        return {"FINISHED"}
    def invoke(self, context, event):
        wm = context.window_manager
        wm.fileselect_add(self)
        return {"RUNNING_MODAL"}


rig_name = "OG_RABBIT"
fk_arm_l = ["UpperArm.L", "Forearm.L", "Hand.L"]
fk_arm_r = ["UpperArm.R", "Forearm.R", "Hand.R"]
ik_arm_l = ["HandIk.L", "HandIkTarget.L"]
ik_arm_r = ["HandIk.R", "HandIkTarget.R"]


class PHXBN_OT_points_to_timeline(bpy.types.Operator):
    bl_label = "To Timeline Operator"
    bl_idname = "phxbn.points_to_timeline"
    bl_description = "Copy start and end points from animation to timeline"
    def invoke(self, context, event):
        obj = context.active_object
        action = obj.animation_data.action
        context.scene.frame_preview_start = int(action["Start"]*bpy.context.scene.render.fps/1000)
        context.scene.frame_preview_end = int(action["End"]*bpy.context.scene.render.fps/1000)
        return{"FINISHED"}


class PHXBN_OT_points_from_timeline(bpy.types.Operator):
    bl_label = "From Timeline Operator"
    bl_idname = "phxbn.points_from_timeline"
    bl_description = "Copy start and end points from timeline to animation"
    def invoke(self, context, event):
        obj = context.active_object
        action = obj.animation_data.action
        action["Start"] = context.scene.frame_preview_start*1000/bpy.context.scene.render.fps
        action["End"] = context.scene.frame_preview_end*1000/bpy.context.scene.render.fps
        return{"FINISHED"}


class PHXBN_PT_anim_ui(bpy.types.Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_label = "Animation Controls"
    # uh oh code smell here v
    val = True
    # probably remove this ^
    @classmethod
    def poll(self, context):
        obj = context.active_object
        if not obj:
            return False
        action = None
        if obj and obj.animation_data:
            action = obj.animation_data.action
        if not action:
            return False
        if not action.get("Start"):
            action["Start"] = 0
        if not action.get("End"):
            action["End"] = 100
        return True
    def draw(self, context):
        layout = self.layout
        col = layout.column()
        obj = context.active_object
        action = obj.animation_data.action
        looping = col.row()
        looping.prop(action, '["Looping"]', toggle=True, text="Looping")
        to_timeline = col.row()
        to_timeline.operator("phxbn.points_to_timeline", text="To Timeline")
        from_timeline = col.row()
        from_timeline.operator("phxbn.points_from_timeline", text="From Timeline")


class PHXBN_PT_rig_ui(bpy.types.Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_label = "Rig Main Properties"
    @classmethod
    def poll(self, context):
        if context.mode != "POSE":
            return False
        try:
            return(context.active_object.data.get("rig_name") == rig_name)
        except (AttributeError, KeyError, TypeError):
            return False
    def draw(self, context):
        layout = self.layout
        pose_bones = context.active_object.pose.bones
        try:
            selected_bones = [bone.name for bone in context.selected_pose_bones]
            selected_bones += [context.active_pose_bone.name]
        except (AttributeError, TypeError):
            return
        def is_selected(names):
            for name in names:
                if name in selected_bones:
                    return True
            return False
        if is_selected(fk_arm_l + ik_arm_l):
            layout.prop(pose_bones["HandIk.L"], '["ik"]', text = "IK (left arm)", slider = True)
        if is_selected(fk_arm_r + ik_arm_r):
            layout.prop(pose_bones["HandIk.R"], '["ik"]', text = "IK (right arm)", slider = True)


class PHXBN_PT_rig_layers(bpy.types.Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_label = "Rig Layers"
    @classmethod
    def poll(self,context):
        try:
            return (context.active_object.data.get("rig_name") == rig_name)
        except (AttributeError, KeyError, TypeError):
            return False
    def draw(self, context):
        layout = self.layout
        col = layout.column()
        body = col.row()
        body.label(text="Body:")
        body.prop(context.active_object.data, "layer", index = 16, toggle=True, text="Simple")
        body.prop(context.active_object.data, "layer", index = 17,   toggle=True, text="Detail")
        arm_l = col.row()
        arm_l.label(text="Left Arm:")
        arm_l.prop(context.active_object.data, "layer", index = 2, toggle=True, text="FK")
        arm_l.prop(context.active_object.data, "layer", index = 3, toggle=True, text="IK")
        arm_r = col.row()
        arm_r.label(text="Right Arm:")
        arm_r.prop(context.active_object.data, "layer", index = 4, toggle=True, text="FK")
        arm_r.prop(context.active_object.data, "layer", index = 5, toggle=True, text="IK")
        #test = col.row()
        #test.label(text="Action: "+context.active_object.animation_data.action.name)

def register():
    bpy.utils.register_class(PHXBN_OT_points_from_timeline)
    bpy.utils.register_class(PHXBN_OT_points_to_timeline)
    bpy.utils.register_class(PHXBN_OT_export)
    bpy.utils.register_class(PHXBN_OT_import)
    bpy.utils.register_class(PHXBN_PT_anim_ui)
    bpy.utils.register_class(PHXBN_PT_rig_ui)
    bpy.utils.register_class(PHXBN_PT_rig_layers)
    bpy.types.TOPBAR_MT_file_import.append(menu_import)
    bpy.types.TOPBAR_MT_file_export.append(menu_export)

def unregister():
    bpy.types.TOPBAR_MT_file_import.remove(menu_import)
    bpy.types.TOPBAR_MT_file_export.remove(menu_export)
    bpy.utils.unregister_class(PHXBN_OT_points_from_timeline)
    bpy.utils.unregister_class(PHXBN_OT_points_to_timeline)
    bpy.utils.unregister_class(PHXBN_OT_export)
    bpy.utils.unregister_class(PHXBN_OT_import)
    bpy.utils.unregister_class(PHXBN_PT_anim_ui)
    bpy.utils.unregister_class(PHXBN_PT_rig_ui)
    bpy.utils.unregister_class(PHXBN_PT_rig_layers)

